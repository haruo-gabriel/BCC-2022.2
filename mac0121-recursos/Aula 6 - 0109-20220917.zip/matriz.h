int ** alocaMatriz (int lin, int col);
void liberaMatriz (int ** mat, int lin);
void imprimeMatriz (int **a, int m, int n);
